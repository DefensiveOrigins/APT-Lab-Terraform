New-SMBShare -Name "LABS" -Path "C:\LABS" -FullAccess "labs.local\Domain Users"
$acl = Get-Acl -Path C:\LABS
#List Users/Groups in ACL with permissions
$acl.Access | Select IdentityReference, FileSystemRights
#Add ACE to grant Group ReadAndExecute for "This Folder, Subfolders and Files"
$rule = New-Object System.Security.AccessControl.FileSystemAccessRule("Everyone","ReadAndExecute", "ContainerInherit, ObjectInherit", "None", "Allow")
$acl.AddAccessRule($rule)
#Set the modified ACL
Set-Acl -Path C:\LABS -AclObject $aclNew-SMBShare -Name "LABS" -Path "C:\LABS" -FullAccess "labs.local\Domain Users"
